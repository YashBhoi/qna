"""Experiment 4: count how many times each word appears in a string."""
import string

text = input('Enter a string: ')
text = text.lower().translate(str.maketrans('', '', string.punctuation))

counts = {}
for word in text.split():
    counts[word] = counts.get(word, 0) + 1

print('Word frequency:')
for word, c in counts.items():
    print(f'{word} : {c}')
