"""Experiment 5: shopping cart class (add, remove, total)."""


class ShoppingCart:
    def __init__(self):
        self.items = {}   # name -> [price, quantity]

    def add_item(self, name, price, qty=1):
        if name in self.items:
            self.items[name][1] += qty
        else:
            self.items[name] = [price, qty]
        print(f'Added {qty} x {name}')

    def remove_item(self, name):
        if name in self.items:
            del self.items[name]
            print(f'Removed {name}')
        else:
            print(f'{name} is not in the cart')

    def total(self):
        return sum(price * qty for price, qty in self.items.values())

    def show(self):
        print('Cart contents:')
        for name, (price, qty) in self.items.items():
            print(f'{name} - Rs.{price} x {qty} = Rs.{price * qty}')
        print(f'Total: Rs.{self.total()}')


cart = ShoppingCart()
cart.add_item('Laptop', 55000, 1)
cart.add_item('Mouse', 500, 2)
cart.add_item('Keyboard', 1200, 1)
cart.show()
cart.remove_item('Mouse')
print(f'Total after removal: Rs.{cart.total()}')
