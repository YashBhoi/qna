"""Experiment 2: library inventory system using classes and objects."""


class Book:
    def __init__(self, title, author, copies):
        self.title = title
        self.author = author
        self.copies = copies

    def __str__(self):
        return f'{self.title} by {self.author} - Copies: {self.copies}'


class Library:
    def __init__(self):
        self.books = {}

    def add_book(self, book):
        if book.title in self.books:
            self.books[book.title].copies += book.copies
        else:
            self.books[book.title] = book
        print(f'Added: {book.title}')

    def issue_book(self, title):
        book = self.books.get(title)
        if book and book.copies > 0:
            book.copies -= 1
            print(f'Issued: {title}')
        else:
            print(f'Sorry, {title} is not available')

    def return_book(self, title):
        if title in self.books:
            self.books[title].copies += 1
            print(f'Returned: {title}')
        else:
            print('This book does not belong to our library')

    def display(self):
        print('--- Library Inventory ---')
        for book in self.books.values():
            print(book)


lib = Library()
lib.add_book(Book('Python Crash Course', 'Eric Matthes', 3))
lib.add_book(Book('Django for Beginners', 'William Vincent', 2))
lib.display()
lib.issue_book('Python Crash Course')
lib.issue_book('Clean Code')
lib.return_book('Python Crash Course')
lib.display()
