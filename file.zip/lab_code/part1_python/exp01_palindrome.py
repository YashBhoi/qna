"""Experiment 1: check if a string is a palindrome."""


def is_palindrome(text):
    cleaned = ''.join(ch.lower() for ch in text if ch.isalnum())
    return cleaned == cleaned[::-1]


s = input('Enter a string: ')
if is_palindrome(s):
    print(s, 'is a palindrome')
else:
    print(s, 'is not a palindrome')
