# Python With Django - Lab Manual Code (Yash Bhoi)

All 15 practicals, fully runnable and tested (8 automated tests pass).

## Setup (once)
    pip install -r requirements.txt

## Experiments 1-5  (plain Python, folder part1_python/)
    cd part1_python
    python exp01_palindrome.py
    python exp02_library_inventory.py
    python exp03_fibonacci.py
    python exp04_word_count.py
    python exp05_shopping_cart.py

## Experiments 6-15  (Django project, folder MyWebsite/)
    cd MyWebsite
    python manage.py migrate            # Exp 12: creates Book (and Product) tables
    python manage.py seed_demo          # adds 3 books + admin user (admin / admin12345)
    python manage.py runserver          # Exp 7: open http://127.0.0.1:8000/

| Exp | What                              | Where to see it                                   |
|-----|-----------------------------------|---------------------------------------------------|
| 6   | API + JSON 404 for invalid routes | /api/  and  /api/anything  (404 JSON)             |
|     | custom 404 for ALL bad URLs       | DJANGO_DEBUG=False python manage.py runserver     |
|     |                                   | (Windows: set DJANGO_DEBUG=False first)           |
| 7   | Project MyWebsite + server        | python manage.py runserver                        |
| 8   | App "blog" registered             | MyWebsite/settings.py -> INSTALLED_APPS           |
| 9   | Hello, Django!                    | /hello/                                           |
| 10  | Name + profession template        | /profile/                                         |
| 11  | base / home / about templates     | /  and  /about/                                   |
| 12  | Book model + migrations           | blog/models.py, blog/migrations/                  |
| 13  | Admin books, ORM list, form       | /admin/ , /books/ , /contact/                     |
| 14  | Login/logout + CSS static         | /accounts/login/ , static/css/style.css           |
| 15  | DRF CRUD on Product               | /products/  (browsable API)                       |

## Exp 15 curl examples
    curl -X POST http://127.0.0.1:8000/products/ -H "Content-Type: application/json" -d '{"name":"Laptop","price":"55000.00","quantity":10}'
    curl http://127.0.0.1:8000/products/
    curl -X PUT http://127.0.0.1:8000/products/1/ -H "Content-Type: application/json" -d '{"name":"Laptop","price":"52000.00","quantity":8}'
    curl -X DELETE http://127.0.0.1:8000/products/1/

## Run the automated tests
    python manage.py test
