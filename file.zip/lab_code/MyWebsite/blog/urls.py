from django.urls import path, re_path
from rest_framework.routers import DefaultRouter

from . import views

urlpatterns = [
    path('', views.home, name='home'),                      # Exp 11
    path('about/', views.about, name='about'),              # Exp 11
    path('hello/', views.hello, name='hello'),              # Exp 9
    path('profile/', views.profile, name='profile'),        # Exp 10
    path('books/', views.book_list, name='book_list'),      # Exp 13 A
    path('contact/', views.contact, name='contact'),        # Exp 13 B
    path('api/', views.api_home, name='api_home'),          # Exp 6
    re_path(r'^api/(?P<path>.+)$', views.api_not_found),    # Exp 6 (invalid API routes)
]

# Exp 15: /products/ CRUD API
router = DefaultRouter()
router.register('products', views.ProductViewSet)
urlpatterns += router.urls
