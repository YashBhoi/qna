from django.contrib import admin
from .models import Book, Product

admin.site.register(Book)      # Exp 13
admin.site.register(Product)
