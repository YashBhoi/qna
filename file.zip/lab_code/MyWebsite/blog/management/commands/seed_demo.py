from datetime import date

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand

from blog.models import Book


class Command(BaseCommand):
    help = 'Create demo books (Exp 13) and an admin user (admin / admin12345).'

    def handle(self, *args, **options):
        books = [
            ('Python Crash Course', 'Eric Matthes', date(2015, 11, 1)),
            ('Django for Beginners', 'William Vincent', date(2018, 3, 1)),
            ('Clean Code', 'Robert C. Martin', date(2008, 8, 1)),
        ]
        for title, author, pub in books:
            Book.objects.get_or_create(title=title, defaults={'author': author, 'published_date': pub})
        User = get_user_model()
        if not User.objects.filter(username='admin').exists():
            User.objects.create_superuser('admin', 'admin@example.com', 'admin12345')
        self.stdout.write(self.style.SUCCESS('Demo data ready. Login: admin / admin12345'))
