from rest_framework import serializers
from .models import Product


# Experiment 15
class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = ['id', 'name', 'price', 'quantity']
