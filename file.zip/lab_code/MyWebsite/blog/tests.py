"""Automated checks for Experiments 6-15.  Run:  python manage.py test"""
import json
from datetime import date

from django.contrib.auth import get_user_model
from django.test import TestCase
from rest_framework.test import APIClient

from .models import Book, Product


class LabTests(TestCase):
    def test_exp6_api_and_404(self):
        r = self.client.get('/api/')
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json(), {'message': 'Welcome to the API'})
        r = self.client.get('/api/xyz')
        self.assertEqual(r.status_code, 404)
        self.assertEqual(r.json()['error'], '404 Not Found')

    def test_exp9_hello(self):
        r = self.client.get('/hello/')
        self.assertEqual(r.content.decode(), 'Hello, Django!')

    def test_exp10_profile(self):
        r = self.client.get('/profile/')
        self.assertContains(r, 'Name: Yash Bhoi')
        self.assertContains(r, 'Profession: Software Engineer')

    def test_exp11_home_about(self):
        self.assertContains(self.client.get('/'), 'Welcome to My Website')
        self.assertContains(self.client.get('/about/'), 'About Us')

    def test_exp12_13_books(self):
        Book.objects.create(title='Clean Code', author='Robert C. Martin', published_date=date(2008, 8, 1))
        self.assertContains(self.client.get('/books/'), 'Clean Code')

    def test_exp13_form(self):
        r = self.client.post('/contact/', {'name': 'Yash Bhoi', 'email': 'yashbhoi013@gmail.com'})
        self.assertContains(r, 'Name: Yash Bhoi')
        self.assertContains(r, 'Email: yashbhoi013@gmail.com')

    def test_exp14_login_logout_static(self):
        get_user_model().objects.create_user('yash', password='pass12345')
        r = self.client.post('/accounts/login/', {'username': 'yash', 'password': 'pass12345'})
        self.assertRedirects(r, '/')
        self.assertContains(self.client.get('/'), 'Hi, yash')
        self.assertContains(self.client.get('/'), 'css/style.css')
        r = self.client.post('/accounts/logout/')
        self.assertRedirects(r, '/accounts/login/')

    def test_exp15_crud(self):
        api = APIClient()
        r = api.post('/products/', {'name': 'Laptop', 'price': '55000.00', 'quantity': 10}, format='json')
        self.assertEqual(r.status_code, 201)
        pid = r.json()['id']
        self.assertEqual(api.get('/products/').json()[0]['name'], 'Laptop')
        r = api.put(f'/products/{pid}/', {'name': 'Laptop', 'price': '52000.00', 'quantity': 8}, format='json')
        self.assertEqual(r.json()['price'], '52000.00')
        self.assertEqual(api.delete(f'/products/{pid}/').status_code, 204)
        self.assertEqual(Product.objects.count(), 0)
