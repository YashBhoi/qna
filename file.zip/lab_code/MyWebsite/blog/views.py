from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from rest_framework import viewsets

from .forms import ContactForm
from .models import Book, Product
from .serializers import ProductSerializer


# ---- Experiment 6: API endpoint + 404 handling -------------------------
def api_home(request):
    return JsonResponse({'message': 'Welcome to the API'})


def custom_404(request, exception=None):
    return JsonResponse(
        {'error': '404 Not Found', 'message': 'The requested route does not exist'},
        status=404,
    )


def api_not_found(request, path=''):
    """Catch-all for /api/<anything-else>: works even when DEBUG=True."""
    return custom_404(request)


# ---- Experiment 9: Hello, Django! --------------------------------------
def hello(request):
    return HttpResponse('Hello, Django!')


# ---- Experiment 10: template with name and profession ------------------
def profile(request):
    context = {
        'name': 'Yash Bhoi',
        'profession': 'Software Engineer & Web/App Developer',
    }
    return render(request, 'blog/profile.html', context)


# ---- Experiment 11: base template + home / about -----------------------
def home(request):
    return render(request, 'blog/home.html')


def about(request):
    return render(request, 'blog/about.html')


# ---- Experiment 13 (Part A): list books using the ORM ------------------
def book_list(request):
    books = Book.objects.all()
    return render(request, 'blog/book_list.html', {'books': books})


# ---- Experiment 13 (Part B): name + email form -------------------------
def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            return render(request, 'blog/result.html', form.cleaned_data)
    else:
        form = ContactForm()
    return render(request, 'blog/form.html', {'form': form})


# ---- Experiment 15: DRF CRUD API ---------------------------------------
class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
