"""URL configuration for MyWebsite (Experiments 6, 9, 14)."""
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('django.contrib.auth.urls')),   # Exp 14: login / logout
    path('', include('blog.urls')),
]

# Exp 6: JSON 404 for any invalid route (used when DEBUG is False)
handler404 = 'blog.views.custom_404'
